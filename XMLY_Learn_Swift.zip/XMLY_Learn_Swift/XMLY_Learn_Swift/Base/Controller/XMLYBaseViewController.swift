//
//  XMLYBaseViewController.swift
//  XMLY_Learn_Swift
//
//  Created by zhaojingyu on 2019/11/5.
//  Copyright © 2019 zhaojingyu. All rights reserved.
//

import UIKit

class XMLYBaseViewController: UIViewController {

    var isHidenNav = false;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
    }
    
    func configUI(){
        
    }
}
