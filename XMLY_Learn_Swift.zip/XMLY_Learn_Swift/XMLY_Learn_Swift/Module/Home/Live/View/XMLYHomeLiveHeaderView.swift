//
//  XMLYHomeLiveHeaderView.swift
//  XMLY_Learn_Swift
//
//  Created by zhaojingyu on 2019/11/7.
//  Copyright © 2019 XMLY. All rights reserved.
//

import UIKit

class XMLYHomeLiveHeaderView: UICollectionReusableView {
        
}
